public class MAIN{
	public static void main(String a[]){
		Navigate n=new Navigate();
		n.setVisible(true);
	}
}