import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Navigate extends JFrame implements ActionListener{
	private Button signupButton,loginButton;
	public static Login log;
	public static Signup sup;
	public static Home home;
	public static Edit edit;
	public Navigate(){
		super("Navigation Window");
		log=new Login();
		sup=new Signup();
		home=new Home();
		edit=new Edit();
		loginButton=new Button("Login");
		signupButton=new Button("Signup");
		add(loginButton);add(signupButton);
		signupButton.addActionListener(this);
		loginButton.addActionListener(this);
		setLayout(new FlowLayout());
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocation(1100,100);
		setSize(400,500);
	}
	public void actionPerformed(ActionEvent e){
		//System.out.println(e.getActionCommand());
		String sig=e.getActionCommand();
		if(sig.equals("Signup")){
			this.setVisible(false);
			sup.setVisible(true);
		}
		else if(sig.equals("Login")){
			this.setVisible(false);
			log.setVisible(true);
			log.setParent(this);
		}
		else if(sig.equals("Cancel")){
			System.exit(0);
		}
	}
}