import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class Edit extends Frame implements ActionListener{
	private TextField name,email;
	private Button signupButton,cancelButton;
	private Label l,l2,msg;
	private Frame parent;
	public Edit(){
		super("Java Edit Window");
		l=new Label("Name: ");
		name=new TextField(10);
		l2=new Label("Email: ");
		email=new TextField(10);
		signupButton=new Button("Confirm");
		cancelButton=new Button("Back");
		msg=new Label("msg box");
		add(l);add(name);
		add(l2);add(email);
		add(signupButton);add(cancelButton);
		add(msg);
		
		l.setBounds(10,60,50,30);
		name.setBounds(115,60,200,30);
		l2.setBounds(10,95,100,30);
		email.setBounds(115,95,200,30);
		signupButton.setBounds(115,130,100,30);
		cancelButton.setBounds(220,130,100,30);
		msg.setBounds(115,170,200,30);
		
		signupButton.addActionListener(this);
		cancelButton.addActionListener(this);
		setLayout(null);
		setSize(400,500);
	}
	private boolean isEmpty(TextField s){
		boolean flag=false;
		if(s.getText().length()==0)flag=true;
		//System.out.println(s.getText()+":"+flag);
		return flag;
	}
	public void setParent(Frame p){
		parent=p;
	}
	private boolean isValidEmail(String e){
		boolean flag=true;
		int atIdx=e.indexOf("@");
		int dotIdx=e.indexOf(".");
		if(dotIdx<atIdx)flag=false;
		return flag;
	}
	public void actionPerformed(ActionEvent e){
		//System.out.println(e.getActionCommand());
		String sig=e.getActionCommand();
		
		if(sig.equals("Confirm")){
			String sql="update user set email='"+email.getText()+"' where uname='"+name.getText()+"'";
			System.out.println(sql);
			DataAccess da=new DataAccess();
			if(isEmpty(email) || isEmpty(name)){
				JOptionPane.showMessageDialog(this,"All fields are mandatory");
			}
			else if(!isValidEmail(email.getText())){
				msg.setText("Invalid email");
				JOptionPane.showMessageDialog(this,"Invalid email");
			}
			else{
				if(da.updateDB(sql)>0){
					JOptionPane.showMessageDialog(this,"Data Updated");
					msg.setText("Data Updated");
				}
				else{
					msg.setText("Update Error");
					JOptionPane.showMessageDialog(this,"Update Error!");
				}
			}
		}
		else if(sig.equals("Back")){
			parent.setVisible(true);
			this.setVisible(false);
		}
	}
}